function login() {
    if(document.getElementById('username').value !== "") {
        document.getElementById('login-page').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
    }
}

function logout() {
    document.getElementById('main-content').style.display = 'none';
    document.getElementById('login-page').style.display = 'flex';
    showDashboard();
}

function showSection(id) {
    document.getElementById('dashboard-view').style.display = 'none';
    const sections = document.getElementsByClassName('page-section');
    for(let s of sections) s.style.display = 'none';
    document.getElementById(id).style.display = 'block';
    window.scrollTo(0,0);
}

function showDashboard() {
    const sections = document.getElementsByClassName('page-section');
    for(let s of sections) s.style.display = 'none';
    document.getElementById('dashboard-view').style.display = 'block';
}

function toggleChat() {
    const chat = document.getElementById('chat-modal');
    chat.style.display = (chat.style.display === 'flex') ? 'none' : 'flex';
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    const box = document.getElementById('chat-box');
    const text = input.value.trim();
    if(text !== "") {
        box.innerHTML += `<div style="text-align:left; margin:10px 0;"><span style="background:#eee; padding:8px; border-radius:10px; font-size: 0.85rem;">${text}</span></div>`;
        input.value = "";
        setTimeout(() => {
            let reply = text.includes("متأخر") ? "أبرز المتأخرات هي عقد شركة الخبراء الدولية بـ 15 يوم تأخير." : "لدينا 128 عقداً مسجلاً في النظام حالياً.";
            box.innerHTML += `<div style="background:#e8f5e9; padding:10px; border-radius:10px; margin-bottom:10px; font-size: 0.9rem;">${reply}</div>`;
            box.scrollTop = box.scrollHeight;
        }, 700);
    }
}
